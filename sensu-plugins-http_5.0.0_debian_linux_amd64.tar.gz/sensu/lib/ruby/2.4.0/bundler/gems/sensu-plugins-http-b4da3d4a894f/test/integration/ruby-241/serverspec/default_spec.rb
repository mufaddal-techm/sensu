# frozen_string_literal: true

require 'spec_helper'
require 'shared_spec'
