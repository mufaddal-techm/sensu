# frozen_string_literal: true

require 'serverspec'

set :backend, :exec
