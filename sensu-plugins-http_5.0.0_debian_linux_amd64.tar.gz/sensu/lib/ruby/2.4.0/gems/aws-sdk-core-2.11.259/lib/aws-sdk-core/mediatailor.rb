Aws.add_service(:MediaTailor, {
  api: "#{Aws::API_DIR}/mediatailor/2018-04-23/api-2.json",
  docs: "#{Aws::API_DIR}/mediatailor/2018-04-23/docs-2.json",
  paginators: "#{Aws::API_DIR}/mediatailor/2018-04-23/paginators-1.json",
})
