Aws.add_service(:Pinpoint, {
  api: "#{Aws::API_DIR}/pinpoint/2016-12-01/api-2.json",
  docs: "#{Aws::API_DIR}/pinpoint/2016-12-01/docs-2.json",
  examples: "#{Aws::API_DIR}/pinpoint/2016-12-01/examples-1.json",
})
