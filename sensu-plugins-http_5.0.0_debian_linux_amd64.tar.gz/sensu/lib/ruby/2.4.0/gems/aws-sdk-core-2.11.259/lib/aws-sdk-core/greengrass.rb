Aws.add_service(:Greengrass, {
  api: "#{Aws::API_DIR}/greengrass/2017-06-07/api-2.json",
  docs: "#{Aws::API_DIR}/greengrass/2017-06-07/docs-2.json",
})
