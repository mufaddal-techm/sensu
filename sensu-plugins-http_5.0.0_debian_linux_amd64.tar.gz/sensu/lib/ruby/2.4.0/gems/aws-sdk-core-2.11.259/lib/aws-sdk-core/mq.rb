Aws.add_service(:MQ, {
  api: "#{Aws::API_DIR}/mq/2017-11-27/api-2.json",
  docs: "#{Aws::API_DIR}/mq/2017-11-27/docs-2.json",
  paginators: "#{Aws::API_DIR}/mq/2017-11-27/paginators-1.json",
})
