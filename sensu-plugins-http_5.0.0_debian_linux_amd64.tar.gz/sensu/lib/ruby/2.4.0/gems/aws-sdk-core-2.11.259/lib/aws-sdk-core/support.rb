Aws.add_service(:Support, {
  api: "#{Aws::API_DIR}/support/2013-04-15/api-2.json",
  docs: "#{Aws::API_DIR}/support/2013-04-15/docs-2.json",
  examples: "#{Aws::API_DIR}/support/2013-04-15/examples-1.json",
  paginators: "#{Aws::API_DIR}/support/2013-04-15/paginators-1.json",
})
