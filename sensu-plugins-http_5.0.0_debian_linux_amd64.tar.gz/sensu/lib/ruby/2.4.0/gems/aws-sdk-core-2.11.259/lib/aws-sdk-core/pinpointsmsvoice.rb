Aws.add_service(:PinpointSMSVoice, {
  api: "#{Aws::API_DIR}/sms-voice/2018-09-05/api-2.json",
  docs: "#{Aws::API_DIR}/sms-voice/2018-09-05/docs-2.json",
})
