require 'simplecov'
SimpleCov.start
